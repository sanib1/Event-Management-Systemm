<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<head>
<?php include"head.php";?> 
  </head>
<body>
<div class="left-content">
<div class="outter-wp">
<div class="sub-heard-part">
</div>
<p>
<h3 class="inner-tittle two">Event List</h3>

<div class="form-body">
<table id="dtBasicExample" class="table table-striped table-bordered" cellspacing="0" width="100%">
  <thead>
    <tr>
	<th class="th-sm">S.no.
      </th>
      <th class="th-sm">Name
      </th>
      <th class="th-sm">Date
      </th>
      <th class="th-sm">Time
      </th>
	  <th class="th-sm">Mobile
      </th>
       <th class="th-sm">Address
      </th><th class="th-sm">View
      </th>
	   <th class="th-sm">Status</th>
	   
    </tr>
  </thead>
  <tbody>
  <?php 
  $result=select("SELECT * FROM event where status!='0' ");
  $n=1;
  while($r=mysqli_fetch_array($result))
  {  extract($r);
  ?>
    <tr>
	   <td><?=$n?></td>
      <td><input type="hidden" name="userid" value="<?=$r['userid']?>"><?=ucwords($title)?></td>
      <td><?=$date_from?> To <?=$date_to?></td>
       <td><?=$time_from?> To <?=$time_to?></td>
     
	  <td><?=$mobile?>  </td>
      <td><?=ucwords($address)?></td>
      <td><a href="special.php?id=<?=$id?>"><button class="btn btn-info"> View Details</button></a></td>
      
      <td><?php
					if($status==0) {echo"Pending";}
					if($status==11){echo"Team A";}
					if($status==22){echo"Team B";}
					if($status==33){echo"Team C";}
					?> 
	  </td>
      
    </tr>
    
    <?php
	$n++;
  }
	?>
   
    
    </tbody>

</table>
</div>


</p>
</div>

</div>

</div>
</div>

</div>
</div>
<?php include"side_bar.php";?>
</div>

</body>
</html>