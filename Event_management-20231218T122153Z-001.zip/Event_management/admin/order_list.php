<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
}
else
{
	header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<head>
<?php include"head.php";?> 
  </head>
<body>
<div class="left-content">
<div class="outter-wp">
<div class="sub-heard-part">
</div>
<p>
<h3 class="inner-tittle two">Pending Event List</h3>

<div class="form-body">
<table id="dtBasicExample" class="table table-striped table-responsive table-bordered">
  <thead>
    <tr>
	<th class="th-sm">S.no.
      </th>
      <th class="th-sm">Event Title
      </th>
      <th class="th-sm">Date
      </th>
      <th class="th-sm">Time
      </th>
	  <th class="th-sm">Mobile
      </th>
       <th class="th-sm">Address
      </th>
	   <th class="th-sm">Allot</th>
	 
    </tr>
  </thead>
  <tbody>
  <?php 
  $result=select("SELECT * FROM `event` where status='0' ");
  $n=1;
  while($r=mysqli_fetch_array($result))
  {  extract($r);
  ?>
    <tr>
	<form method="post">
      <td><?=$n?></td>
      <td><input type="hidden" name="userid" value="<?=$r['userid']?>"><?=ucwords($title)?></td>
      <td><?=$date_from?> To <?=$date_to?></td>
       <td><?=$time_from?> To <?=$time_to?></td>
     
	  <td><?=$mobile?>  </td>
      <td><?=ucwords($address)?></td>
      
      <td><select name="team" ><option>SELECT</option>
	  <option value="11">Team A</option>
	  <option value="22">Team B</option>
	  <option value="33">Team C</option>
</select>
	  <button name="allot" class="bg-danger">Allot</button>
	  </td>
</form>  
    </tr>
    <?php
	$n++;
  }
	?>
    </tbody>
</table>
<?php
if(isset($_REQUEST['allot']))
{
	extract($_REQUEST);
	$n=iud("INSERT INTO `allot`( `useid`, `ownerid`) VALUES ('$userid','$team')");
	if($n==1)
	{
		$t=iud("update event set status='$team' where userid='$userid'");
		if($t==1)
		{	
				echo"<script>alert('Alloted');
				window.location='order_list.php';
				</script>";	
		}
		else
			{		
				echo"<script>alert('Something Wrong2');
				window.location='order_list.php';
				</script>";
			}
}
}
?>
</div>
</p>
</div>
</div>
</div>
</div>
</div>
</div>
<?php include"side_bar.php";?>
</div>
</body>
</html>