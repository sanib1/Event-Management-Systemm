<?php require_once"dbconfig.php";
if(isset($_SESSION['login']))
{
}
else
{
	header("location:login.php");
}
?>
<!DOCTYPE HTML>
<html>
<head>
<?php include"head.php";?>
</head>
<body>
<div class="left-content">
<div class="outter-wp">
<div class="sub-heard-part"></div>
<div class="graph">
<p>
<h3 class="inner-tittle two">Team Member List</h3>
<div class="form-body">
<table id="dtBasicExample" class="table table-striped table-responsive table-bordered">
  <thead>
    <tr>
	<th class="th-sm">S.no.
      </th>
      <th class="th-sm">Name
      </th>
      <th class="th-sm">Team
      </th>
      <th class="th-sm">Mobile
      </th>
    </tr>
  </thead>
  <tbody>
  <?php 
  $result=select("SELECT * FROM `member` ");
  $n=1;
  while($r=mysqli_fetch_array($result))
  {  extract($r);
  ?>
    <tr>
	<form method="post">
      <td><?=$n?></td>
	  <td><?=$name?>  </td>
	  <td><?=$team?>  </td>
	  <td><?=$mobile?>  </td>
</form>
    </tr>
    <?php
	$n++;
  }
	?>
    </tbody>
</table>
</div>
</p>
</div>
</div>
</div>
<?php include"side_bar.php";?>
</div>
</body>
</html>