<div class="sidebar-menu">

</header>
	<div class="down">
</div>	
<div class="menu">
<ul id="menu" >
<?php
if(isset($_SESSION['login']))
{
	?>
<li><a href="index.php"><i class="fa fa-tachometer"></i> <span>Account</span></a></li>
<li><a href="add_member.php"><i class="fa fa-tachometer"></i> <span>Add Team Member</span></a></li>
<li><a href="view_member.php"><i class="fa fa-tachometer"></i> <span>View Team Member</span></a></li>
<li><a href="order_list.php"><i class="fa fa-tachometer"></i> <span>Pending Events</span></a></li>
<li><a href="order_list2.php"><i class="fa fa-tachometer"></i> <span>alloted Events</span></a></li>

<li><a href="logout.php"><i class="fa fa-tachometer"></i> <span>Logout</span></a></li>
<?php }else{ ?>
<li><a href="login.php"><i class="fa fa-tachometer"></i> <span>Login</span></a></li>
<?php } ?>
</ul>
</div>
</div>